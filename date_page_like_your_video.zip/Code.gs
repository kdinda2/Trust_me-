function doGet(e) {
  const p = e.parameter || {};
  const recipient = "YOUR_EMAIL@gmail.com"; // put your Gmail here
  const subject = "💗 Date Surprise — New Choice";
  const body =
    "Someone completed your date page!\n\n" +
    "Answer: " + (p.answer || "") + "\n" +
    "Date: " + (p.date || "") + "\n" +
    "Activity: " + (p.activity || "") + "\n" +
    "Message: " + (p.note || "") + "\n";
  MailApp.sendEmail(recipient, subject, body);
  return ContentService.createTextOutput("OK");
}